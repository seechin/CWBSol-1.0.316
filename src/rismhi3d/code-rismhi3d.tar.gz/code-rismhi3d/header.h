
#define     _GROMACS4_
#define     _LOCALPARALLEL_                 // general local paralleling
#define     _LOCALPARALLEL_PTHREAD_
//#define     _FFTWMPPARALLEL_                // fftw multithreading
#define     _LIBZ_                          // use libz to compress TENSOR4D
#define     _INTERACTIVE_                   // allow interactive mode, undef this will disable main-interactive.cpp

#define     _EXPERIMENTAL_
#define     _TTYPROMPTCOLOR_
//#define     _FUNCTION_EXPORT_
